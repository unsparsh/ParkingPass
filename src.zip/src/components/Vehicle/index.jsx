import { useState } from "react";

export const Vehicle = ({ vehicles, setVehicles, users }) => {
    // Creating state for Vehicle details
    const [vehicleNumber, setVehicleNumber] = useState("");
    const [vehicleType, setVehicleType] = useState("");
    const [user, setUser] = useState("");

    // Function to create new vehicle entry
    const addVehicle = (e) => {
        e.preventDefault(); // Prevents page reload

        //setVehicles(prevVehicles => [...prevVehicles, { vehicleNumber, vehicleType, user }]);
        setVehicles(prevVehicles => {
            window.localStorage.setItem("VEHICLES" , JSON.stringify([...prevVehicles , {vehicleNumber , vehicleType , user}]))
            return [...prevVehicles , {vehicleNumber , vehicleType , user}]
        })
        alert("Vehicle Successfully Registered");

        // Clear form fields after registration
        setVehicleNumber("");
        setVehicleType("");
        setUser("");
    };

    return (
        <>
            <hr />
            <h1>Vehicle Registration</h1>
            <form onSubmit={addVehicle}>
                {/* Vehicle Number Input */}
                <input
                    type="text"
                    placeholder="Vehicle Number*"
                    pattern="^[A-Z]{2}[- ]?[0-9]{2}[- ]?[A-Z]{2,3}[- ]?[0-9]{4}$"
                    title="Enter a valid Indian vehicle number (e.g., MH12AB1234, KA-01-AA-5678, HR 26 BH 6789)"
                    required
                    value={vehicleNumber}
                    onChange={(e) => setVehicleNumber(e.target.value.toUpperCase())}
                />
                <br />

                {/* Vehicle Type Dropdown */}
                <select
                    value={vehicleType}
                    onChange={(e) => setVehicleType(e.target.value)}
                    required
                >
                    <option value="" disabled>-- Select Vehicle Type --</option>
                    <option value="bike">Bike</option>
                    <option value="car">Car</option>
                </select>
                <br />

                {/* User Selection Dropdown */}
                <select
                    value={user}
                    onChange={(e) => setUser(e.target.value)}
                    required
                >
                    <option value="" disabled>-- Select User --</option>
                    {users.length > 0 ? (
                        users.map((user, index) => (
                            <option key={index} value={user.name}>
                                {user.name} ({user.role})
                            </option>
                        ))
                    ) : (
                        <option value="" disabled>No Users Available</option>
                    )}
                </select>
                <br /><br />

                {/* Submit Button */}
                <input type="submit" value="Register" />
            </form>
        </>
    );
};
