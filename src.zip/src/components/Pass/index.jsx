import '../styles.css'

export const Pass = ()=>{
    return(
        <>
        <hr />
        <h1>Available Pass to Buy</h1>
        <button>Weekly</button>
        <button>Monthly</button>
        <button>Yearly</button>
        </>
    )
}